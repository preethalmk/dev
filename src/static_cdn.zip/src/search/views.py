from django.shortcuts import render
from products.models import Product
from django.views.generic import ListView
from django.db.models import Q

# Create your views here.
class SearchProductView(ListView):
    #queryset= Product.objects.all()
    template_name="search/view.html"

    def get_queryset(self,*args,**kwargs):
        request=self.request
        print(request)
        query=request.GET.get('q')
        if query is not None:
            lookups=(Q(Titile__icontains=query)|
                     Q(description__icontains=query)|
                     Q(tags__Titile__icontains=query)
                    )
            return Product.objects.filter(lookups).distinct()
        return Product.objects.featured()
