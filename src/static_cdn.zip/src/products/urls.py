from django.urls import path,re_path

from .views import (
        ProductListView,
        #product_list_view,
        #ProductDetailView,
        #product_detail_view,
        #ProductFeaturedDetailView,
        ProductFeaturedListView,
        ProductDetailSlugView
        )
app_name = 'products'
urlpatterns = [
    path('', ProductListView.as_view(),name='list'),
    #path('product-fbv/', product_list_view),
    #re_path(r'^product/(?P<pk>\d+)/$', ProductDetailView.as_view()),
    #re_path(r'^product-fbv/(?P<pk>\d+)/$', product_detail_view),
    path('featured/', ProductFeaturedListView.as_view(),name='featured'),
    #re_path(r'^featured/(?P<pk>\d+)/$', ProductFeaturedDetailView.as_view()),
    re_path(r'(?P<slug>[\w-]+)/$',ProductDetailSlugView.as_view(), name="detail"),
]
