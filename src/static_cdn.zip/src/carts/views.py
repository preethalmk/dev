from django.shortcuts import render,redirect
from .models import cart
from products.models import Product
# Create your views here.

def cart_home(request):
    #del request.session['cart_id']
    cart_obj,new_obj=cart.objects.new_or_get(request)
    products=cart_obj.product.all()
    total=0
    for x in products:
        total +=x.price
    cart_obj.total=total
    cart_obj.save()

    return render(request,"carts/home.html",{})

def cart_update(request):
    product_obj=Product.objects.get(id=1)
    cart_obj,new_obj=cart.objects.new_or_get(request)
    cart_obj.product.add(product_obj)
    cart_obj.save()
    return redirect("cart:home")
